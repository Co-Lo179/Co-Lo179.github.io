---
title: "利用例"
date: 2020-08-14
draft: false
description: "Congoの実用例。"
slug: "users"
tags: ["users", "sample"]
showDate: false
showAuthor: false
showReadingTime: false
showEdit: false
---

{{< lead >}}
Congoを使用して構築された実際のウェブサイト。
{{< /lead >}}

以下は、Congoを使って構築されたウェブサイトのほんの一握りです。このテーマでできることの素晴らしさをご覧ください。

| Website                                                          | Details                           |
| ---------------------------------------------------------------- | --------------------------------- |
| [jamespanther.com](https://jamespanther.com)                     | Personal site - Theme author      |
| [antoinesoetewey.com](https://antoinesoetewey.com/)              | Personal site                     |
| [leif.io](https://leif.io/)                                      | Personal site and Tech blog       |
| [dr460nf1r3.org](https://dr460nf1r3.org/)                        | Personal site and Blog            |
| [OCram85.com](https://ocram85.com)                               | Personal site and Blog            |
| [jamesmillner.dev](https://jamesmillner.dev)                     | Personal site and Blog            |
| [jeremic.ca](https://jeremic.ca)                                 | Personal site and Blog            |
| [rohn.tech](https://rohn.tech)                                   | Personal site                     |
| [kelset.dev](https://kelset.dev)                                 | Personal site                     |
| [ruihao-li.github.io](https://ruihao-li.github.io/)              | Personal site and Blog            |
| [phalanxhead.dev](https://phalanxhead.dev)                       | Personal site and Blog            |
| [Bible Multi Apps](https://biblemulti.org)                       | Personal site and Blog            |
| [Jh123x](https://jh123x.com/)                                    | Personal site and Blog            |
| [sforzando LLC. and Inc.](https://sfz.dev/)                      | Corporate site and Blog           |
| [szegedkungfu.hu](https://szegedkungfu.hu/)                      | Sports association site           |
| [medical-humanities](https://medical-humanities.org)             | Academic site                     |
| [boyersnet.com](https://boyersnet.com)                           | Personal site and Blog            |
| [major.io](https://major.io)                                     | Personal site and Blog            |
| [顾宇的博客](https://www.guyu.me/)                               | Personal Blog (in Chinese)        |
| [cgutierr-zgz.github.io](https://cgutierr-zgz.github.io/)        | Personal site and Tech blog       |
| [adam.sr](https://adam.sr)                                       | Personal site and Blog            |
| [kpavlov.me](https://kpavlov.me)                                 | Personal site and Blog            |
| [pfisterer.dev](https://pfisterer.dev)                           | Personal site and Blog            |
| [davidrothera.me](https://davidrothera.me)                       | Personal site and Blog            |
| [sathyabh.at](https://sathyabh.at)                               | Personal Site and Blog            |
| [leonidasv.com](https://leonidasv.com/)                          | Personal site and Blog            |
| [andrew-jones.com](https://andrew-jones.com/)                    | Personal site and tech blog       |
| [nikita.computer](https://nikita.computer/)                      | Personal site and tech blog       |
| [spiffyeight77.com](https://spiffyeight77.com/)                  | Personal blog                     |
| [Tomy's Blog](https://blog.tomy.me)                              | Personal site and Blog            |
| [Beerjoa Blog](https://blog.beerjoa.dev)                         | Personal site and Blog            |
| [simaosilva.com](https://simaosilva.com)                         | Personal Site                     |
| [kom.al](https://kom.al)                                         | Personal Site                     |
| [andrea.mortaro.it](https://andrea.mortaro.it)                   | Personal Site and Blog            |
| [jamesjarvis.io](https://jamesjarvis.io)                         | Personal Site and Blog            |
| [jnsgr.uk](https://jnsgr.uk)                                     | Personal site and blog            |
| [stupidjoey.net](https://stupidjoey.net)                         | Personal Site and Tech blog       |
| [aminelch.github.io](https://aminelch.github.io)                 | Personal Site and Blog            |
| [robertboscacci.com](https://robertboscacci.com)                 | Personal Site and Blog            |
| [gorbe.io](https://www.gorbe.io)                                 | Business Site and Blog            |
| [techwolf12.nl](https://techwolf12.nl)                           | Personal Site and Tech Blog       |
| [kylecapehart.com](https://kylecapehart.com/)                    | Personal Site and Blog            |
| [mattstrayer.com](https://www.mattstrayer.com/)                  | Personal Site and Blog            |
| [noamlerner.com](https://noamlerner.com/)                        | Personal blog (English/Hebrew)    |
| [jneidel.com](https://jneidel.com)                               | Personal site and blog            |
| [clementfouque.com](https://clementfouque.com)                   | Personal Site and Tech Blog       |
| [chenyu.blog](https://chenyu.blog)                               | Personal site and blog            |
| [g-snipes.github.io](https://g-snipes.github.io./)               | Personal site and Music/Tech blog |
| [aimtune.dev](https://aimtune.dev/)                              | Personal blog (Turkish/English)   |
| [socrabytes.github.io](https://socrabytes.github.io)             | Personal site and Tech Blog       |
| [blog.pitermarx.com](https://blog.pitermarx.com)                 | Personal Site                     |
| [montenegrodanielfelipe.com](https://montenegrodanielfelipe.com) | Personal Site and Blog            |
| [euangelos.linardos.gr](https://euangelos.linardos.gr)           | Personal Site and Blog            |
| [Rwhither's Blog](https://blog.sky123.top)                       | Personal site and blog            |
| [wendyliga.com](https://wendyliga.com)                           | Personal Site and Blog            |
| [bitingbytes.de](https://bitingbytes.de)                         | Personal Site and Blog            |
| [janela.digital](https://janela.digital/)                        | Personal Blog (in Portuguese)     |
| [leavex.eu](https://leavex.eu)                                   | Leave X Campaign Site             |
| [cmp1315.com](https://cmp1315.com/)                              | Site for medical center           |
| [Yan Dong](https://www.yandong.xyz/en/)                          | Personal Site (Chinese/English)   |
| [reliable.codes](https://reliable.codes/)                        | Professional site (programming)   |
| [softwarewitchcraft.com](https://softwarewitchcraft.com/)        | Personal Blog                     |

**Congoを使っていますか？** あなたのウェブサイトを加えるために[Pull Request](https://github.com/jpanther/congo/blob/dev/exampleSite/content/users/index.md)を投げてください。
